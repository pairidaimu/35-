package top.littledavid.snake


object SnakeGameConfiguration {
    var GRID_WIDTH = 0F
    var GRID_HEIGHT = 0F

    val GAME_COLUMN_COUNT = 20
    val GAME_ROW_COUNT = 20
}