package top.littledavid.snake.callbacks


 //贪吃蛇吃到食物的回调
interface OnEatenFoodListener {
    fun onEaten()
}