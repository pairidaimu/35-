package top.littledavid.snake.callbacks


 //贪吃蛇撞毁的回调

interface OnCrashListener {
    fun onCrash()
}