package top.littledavid.snake

import android.graphics.Color
import android.graphics.Paint


object SnakeGamePaint {

    //  画蛇身体的画笔

    val snakeBodyPaint = Paint().apply {
        isDither = true
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.GREEN
    }


     // 画蛇头部的画笔

    val snakeHeaderPaint = Paint().apply {
        isDither = true
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.BLUE
    }

    //画食物的画笔

    val foodPaint = Paint().apply {
        isDither = true
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.RED
    }

    //画墙壁的画笔

    val wallPaint = Paint().apply {
        isDither = true
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.BLACK
    }
}