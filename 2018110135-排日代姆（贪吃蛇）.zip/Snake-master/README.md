# Snake
Android-贪吃蛇小游戏 Kotlin语言实现

### 效果图

![效果图](https://github.com/littledavid-tech/Snake/blob/master/img/snake.gif)

